Harmless nested test archive for the Sekoia VMRay1 integration: zip in zip in zip, several files at each level.
