@echo off
echo hello from a harmless test file
