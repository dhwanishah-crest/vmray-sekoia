Write-Host 'hello from a harmless test file'
